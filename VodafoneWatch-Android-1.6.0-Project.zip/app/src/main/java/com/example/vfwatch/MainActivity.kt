package com.example.vfwatch

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.InputType
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(CheckWorker.PREFS, Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var counter: TextView
    private lateinit var counterCaption: TextView
    private lateinit var lastCheck: TextView
    private lateinit var history: TextView
    private lateinit var inventoryStatus: TextView
    private lateinit var modeSummary: TextView
    private lateinit var physicalTab: Button
    private lateinit var esimTab: Button
    private lateinit var numberQuery: EditText
    private lateinit var numberResults: TextView
    private lateinit var analysisResults: TextView
    private lateinit var monitorButton: Button
    private var latestSearchResults: List<String> = emptyList()
    private var selectedSimMode: String = "physical"
    private val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()
        buildScreen()
        render()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(Color.rgb(247, 248, 250))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }

        page.addView(label("VODAFONE WATCH", 13, Color.rgb(210, 25, 45), true))
        page.addView(label("مراقبة أرقام RED", 27, Color.rgb(28, 34, 43), true).apply {
            setPadding(0, dp(5), 0, dp(5))
        })
        page.addView(label("متابعة عدّاد Number of Lines واكتشاف التغيّرات", 14, Color.DKGRAY, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(Color.WHITE)
            elevation = dp(2).toFloat()
        }
        page.addView(card, topMargin(22))

        status = label("● في انتظار أول فحص", 14, Color.GRAY, true)
        card.addView(status)
        counter = label("—", 38, Color.rgb(35, 40, 48), true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(4))
        }
        card.addView(counter)
        counterCaption = label("قيمة العداد", 13, Color.GRAY, false).apply {
            gravity = Gravity.CENTER
        }
        card.addView(counterCaption)
        lastCheck = label("لم يُنفّذ أي فحص بعد", 13, Color.DKGRAY, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        card.addView(lastCheck)
        modeSummary = label("SIM Card وeSIM: لم تُقرأ البيانات بعد", 13, Color.DKGRAY, false).apply {
            setPadding(0, dp(14), 0, 0)
        }
        card.addView(modeSummary)

        page.addView(actionButton("افحص الآن", true) { runManualCheck() }, topMargin(18))
        monitorButton = actionButton("ابدأ المراقبة كل 15 دقيقة", false) { startMonitoring() }
        page.addView(monitorButton, topMargin(10))
        page.addView(actionButton("إيقاف المراقبة", false) { stopMonitoring() }, topMargin(10))
        page.addView(actionButton("فتح صفحة اختيار أرقام RED الرسمية", false) { openVodafonePage() }, topMargin(10))

        page.addView(sectionTitle("قائمة الأرقام المتاحة"), topMargin(25))
        val modeTabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        physicalTab = modeTab("SIM Card") { selectSimMode("physical") }
        esimTab = modeTab("eSIM") { selectSimMode("esim") }
        modeTabs.addView(physicalTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
        modeTabs.addView(esimTab, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        page.addView(modeTabs, topMargin(10))
        inventoryStatus = label("لم تُقرأ قائمة مكتملة بعد.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(inventoryStatus, topMargin(8))
        numberQuery = EditText(this).apply {
            hint = "Dials including — ابحث عن تسلسل داخل الرقم"
            inputType = InputType.TYPE_CLASS_NUMBER
            textDirection = View.TEXT_DIRECTION_LTR
            textSize = 16f
            singleLine = true
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(numberQuery, topMargin(8))
        page.addView(actionButton("ابحث في القائمة المحفوظة", true) { searchSavedNumbers() }, topMargin(8))
        page.addView(actionButton("اختيار رقم عشوائي من القائمة المحفوظة", false) { chooseRandomNumber() }, topMargin(8))
        page.addView(actionButton("نسخ نتائج البحث أو الاختيار", false) { copySearchResults() }, topMargin(8))
        numberResults = label("أدخل رقمًا أو تسلسلًا من رقمين على الأقل لبدء البحث.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
            textDirection = View.TEXT_DIRECTION_LTR
        }
        page.addView(numberResults, topMargin(8))

        page.addView(sectionTitle("تحليل الأرقام المميزة"), topMargin(25))
        page.addView(
            label(
                "يُحلل التطبيق كل قائمة مكتملة تلقائيًا وفق مواصفة 22 نوفمبر 2026، ويعرض جميع التقسيمات والأنماط والعلاقات الرقمية. يمكنك إعادة التحليل يدويًا عند الحاجة.",
                13,
                Color.DKGRAY,
                false
            ),
            topMargin(6)
        )
        page.addView(actionButton("إعادة تحليل القائمة وفق المواصفة الفنية", true) { analyzeSavedNumbers() }, topMargin(8))
        page.addView(actionButton("نسخ تقرير التحليل كاملًا", false) { copyAnalysisReport() }, topMargin(8))
        analysisResults = label("سيظهر التقرير تلقائيًا بعد أول فحص مكتمل. اختر SIM Card أو eSIM لعرض تقرير كل نوع مستقلًا.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        page.addView(analysisResults, topMargin(8))

        page.addView(sectionTitle("سجل آخر الفحوصات"), topMargin(25))
        history = label("لا توجد سجلات بعد.", 13, Color.DKGRAY, false).apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        page.addView(history, topMargin(8))
        page.addView(
            label(
                "ملاحظة: الفحص الدوري مضبوط على الحد الأدنى الذي يسمح به أندرويد (15 دقيقة)، وقد يتأخر التنفيذ لتوفير البطارية أو عند انقطاع الإنترنت.",
                12,
                Color.GRAY,
                false
            ).apply { setPadding(0, dp(18), 0, 0) }
        )
        setContentView(scroll)
    }

    private fun render() {
        val loaded = prefs.getInt("loaded", -1)
        val total = prefs.getInt("total", -1)
        val count = prefs.getInt("count", -1)
        val mode = prefs.getString("counter_mode", "single") ?: "single"
        val successTime = prefs.getLong("time", 0L)
        val attemptTime = prefs.getLong("attempt_time", 0L)
        val ok = prefs.getBoolean("last_ok", true)
        val error = prefs.getString("error", "") ?: ""
        val source = prefs.getString("source", "") ?: ""
        val modeWarnings = prefs.getString("mode_warnings", "") ?: ""
        val running = prefs.getBoolean("monitoring", false)

        status.text = when {
            !ok -> "● تعذّر آخر فحص"
            successTime == 0L -> "● في انتظار أول فحص"
            else -> "● آخر فحص ناجح"
        }
        status.setTextColor(if (!ok) Color.rgb(190, 70, 45) else Color.rgb(35, 145, 85))

        counter.text = when {
            mode == "pair" && loaded >= 0 && total >= 0 -> "$loaded / $total"
            count >= 0 -> count.toString()
            total >= 0 -> total.toString()
            else -> "—"
        }
        val primaryModeLabel = modeLabel(prefs.getString("last_primary_mode", "physical") ?: "physical")
        counterCaption.text = if (mode == "pair") {
            "$primaryModeLabel — عدد الأرقام المحمّلة / العدد الإجمالي"
        } else {
            "$primaryModeLabel — قيمة عدّاد Number of Lines"
        }

        val dateLine = if (successTime > 0L) "آخر قراءة ناجحة: ${formatDate(successTime)}" else "لا توجد قراءة ناجحة محفوظة"
        val attemptLine = if (attemptTime > 0L) "آخر محاولة: ${formatDate(attemptTime)}" else ""
        lastCheck.text = listOfNotNull(
            dateLine,
            attemptLine.takeIf { it.isNotBlank() },
            ("مصدر القراءة: $source").takeIf { successTime > 0L && source.isNotBlank() },
            ("أنواع الشرائح التي قُرئت: ${prefs.getInt("last_modes_checked", 0)} من 2").takeIf { successTime > 0L },
            error.takeIf { !ok && it.isNotBlank() },
            ("ملاحظات الفحص: $modeWarnings").takeIf { modeWarnings.isNotBlank() }
        ).joinToString("\n")

        monitorButton.text = if (running) "المراقبة مفعّلة — كل 15 دقيقة" else "ابدأ المراقبة كل 15 دقيقة"
        modeSummary.text = "SIM Card: ${modeSummaryLine("physical")}\neSIM: ${modeSummaryLine("esim")}"
        physicalTab.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (selectedSimMode == "physical") Color.rgb(210, 25, 45) else Color.WHITE
        )
        esimTab.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (selectedSimMode == "esim") Color.rgb(210, 25, 45) else Color.WHITE
        )
        physicalTab.setTextColor(if (selectedSimMode == "physical") Color.WHITE else Color.rgb(175, 20, 40))
        esimTab.setTextColor(if (selectedSimMode == "esim") Color.WHITE else Color.rgb(175, 20, 40))
        renderSelectedInventory()
        renderSavedAnalysis()
        history.text = renderHistory()
    }

    private fun renderHistory(): String {
        val data = try {
            JSONArray(prefs.getString("history", "[]"))
        } catch (_: Exception) {
            JSONArray()
        }
        if (data.length() == 0) return "لا توجد سجلات بعد."

        val lines = mutableListOf<String>()
        for (i in data.length() - 1 downTo maxOf(0, data.length() - 8)) {
            val item = data.optJSONObject(i) ?: continue
            val time = formatDate(item.optLong("time"))
            if (!item.optBoolean("ok", true)) {
                lines.add("$time  •  تعذّر الفحص: ${item.optString("error")}")
                continue
            }
            val modes = item.optJSONArray("modes")
            if (modes != null) {
                val modeLines = mutableListOf<String>()
                for (j in 0 until modes.length()) {
                    val mode = modes.optJSONObject(j) ?: continue
                    val label = mode.optString("sim_label", modeLabel(mode.optString("sim_type")))
                    val value = if (mode.optString("counter_mode") == "pair")
                        "${mode.optInt("loaded")} / ${mode.optInt("total")}"
                    else mode.optInt("count").toString()
                    val listState = if (mode.optBoolean("numbers_complete"))
                        "${mode.optInt("numbers")} رقمًا مكتملًا"
                    else "قائمة غير مكتملة (${mode.optInt("numbers")} رقمًا)"
                    val price = mode.optString("price").takeIf { it.isNotBlank() }?.let { " — $it" }.orEmpty()
                    modeLines.add("$label: $value$price — $listState")
                }
                val change = item.optString("change")
                lines.add("$time\n${modeLines.joinToString("\n")}" + if (change.isNotBlank()) "\n$change" else "")
            } else {
                val value = if (item.optString("mode") == "pair")
                    "${item.optInt("loaded")} / ${item.optInt("total")}"
                else item.optInt("count").toString()
                val change = item.optString("change")
                lines.add("$time  •  $value" + if (change.isNotBlank()) "\n$change" else "")
            }
        }
        return lines.joinToString("\n\n")
    }

    private fun modeLabel(mode: String): String = when (mode) {
        "physical" -> "SIM Card"
        "esim" -> "eSIM"
        else -> "نوع شريحة غير محدد"
    }

    private fun modePrefix(mode: String = selectedSimMode) = "mode_$mode"

    private fun modeSummaryLine(mode: String): String {
        val prefix = modePrefix(mode)
        val time = prefs.getLong("${prefix}_time", 0L)
        if (time == 0L) return "لم تُقرأ بعد"
        val value = if (prefs.getString("${prefix}_counter_mode", "single") == "pair")
            "${prefs.getInt("${prefix}_loaded", -1)} / ${prefs.getInt("${prefix}_total", -1)}"
        else prefs.getInt("${prefix}_count", -1).toString()
        val price = prefs.getString("${prefix}_price", "").orEmpty().takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()
        val specialCount = prefs.getInt("${prefix}_analysis_accepted", -1)
        val specialLine = if (specialCount >= 0) " • أرقام مميزة: $specialCount" else ""
        return "$value$price$specialLine • ${formatDate(time)}"
    }

    private fun selectSimMode(mode: String) {
        if (mode !in setOf("physical", "esim")) return
        selectedSimMode = mode
        latestSearchResults = emptyList()
        numberResults.text = "أدخل رقمًا أو تسلسلًا من رقمين على الأقل لبدء البحث."
        render()
    }

    private fun modeTab(title: String, action: () -> Unit) = Button(this).apply {
        text = title
        isAllCaps = false
        textSize = 14f
        setOnClickListener { action() }
    }

    private fun renderSelectedInventory() {
        val prefix = modePrefix()
        val listCompleteNow = prefs.getBoolean("${prefix}_list_complete", false)
        val savedListComplete = prefs.getBoolean("${prefix}_saved_list_complete", false)
        val updatedTime = prefs.getLong("${prefix}_number_updated_time", 0L)
        val latestTime = prefs.getLong("${prefix}_time", 0L)
        val numberCount = prefs.getInt("${prefix}_number_count", 0)
        val cardsCount = prefs.getInt("${prefix}_number_cards_count", 0)
        val price = prefs.getString("${prefix}_price", "").orEmpty()
        val priceLine = price.takeIf { it.isNotBlank() }?.let { "السعر كما ظهر في آخر فحص: $it\n" }.orEmpty()

        inventoryStatus.text = when {
            listCompleteNow && updatedTime > 0L ->
                "${modeLabel(selectedSimMode)}\n${priceLine}قائمة مكتملة: $numberCount رقمًا فريدًا من $cardsCount بطاقة\nآخر تحديث للقائمة: ${formatDate(updatedTime)}\nالمصدر: ${prefs.getString("${prefix}_list_source", "غير محدد") ?: "غير محدد"}"
            savedListComplete && updatedTime > 0L ->
                "${modeLabel(selectedSimMode)}\n${priceLine}آخر قائمة مكتملة محفوظة: ${prefs.getInt("${prefix}_saved_number_count", 0)} رقمًا\nتاريخها: ${formatDate(updatedTime)}\nآخر قراءة (${if (latestTime > 0L) formatDate(latestTime) else "غير متاحة"}) لم تؤكد اكتمال القائمة؛ لن تُستبدل اللقطة المحفوظة ببيانات جزئية."
            latestTime > 0L ->
                "${modeLabel(selectedSimMode)}\n${priceLine}العداد قُرئ، لكن القائمة غير مكتملة: $numberCount رقمًا من $cardsCount بطاقة. لن تُستخدم للمقارنة أو البحث."
            else -> "لم تُقرأ بيانات ${modeLabel(selectedSimMode)} بعد. نفّذ فحصًا جديدًا."
        }
    }

    private fun loadRawOccurrences(): List<String>? {
        val stored = prefs.getString("${modePrefix()}_raw_occurrences_json", null) ?: return null
        if (stored.isBlank()) return null
        return try {
            val array = JSONArray(stored)
            (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    private fun analyzeSavedNumbers() {
        if (!prefs.getBoolean("${modePrefix()}_saved_list_complete", false)) {
            analysisResults.text = "لا يمكن التحليل الآن؛ لم تُحفظ قائمة مكتملة لـ${modeLabel(selectedSimMode)}. نفّذ فحصًا ناجحًا أولًا."
            return
        }
        val numbers = loadSavedNumbers()
        if (numbers.isEmpty()) {
            analysisResults.text = "القائمة المحفوظة لا تحتوي على أرقام قابلة للتحليل."
            return
        }
        val analysis = SpecialNumberAnalyzer.analyze(numbers, loadRawOccurrences(), modeLabel(selectedSimMode))
        val prefix = modePrefix()
        prefs.edit()
            .putString("${prefix}_analysis_report", analysis.report)
            .putLong("${prefix}_analysis_time", System.currentTimeMillis())
            .putInt("${prefix}_analysis_accepted", analysis.acceptedNumbers)
            .putInt("${prefix}_analysis_unique", analysis.uniqueNumbers)
            .apply()
        analysisResults.text = analysis.report
        Toast.makeText(
            this,
            "اكتمل التحليل: ${analysis.acceptedNumbers} رقمًا مقبولًا من ${analysis.uniqueNumbers} رقمًا فريدًا",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun renderSavedAnalysis() {
        val report = prefs.getString("${modePrefix()}_analysis_report", null)
        analysisResults.text = report ?: "لم يُحفظ تقرير بعد لقائمة ${modeLabel(selectedSimMode)}. نفّذ فحصًا مكتملًا، أو أعد التحليل بعد حفظ القائمة."
    }

    private fun copyAnalysisReport() {
        val report = prefs.getString("${modePrefix()}_analysis_report", null)
        if (report.isNullOrBlank()) {
            Toast.makeText(this, "لا يوجد تقرير تحليل لنسخه", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Vodafone RED analysis report", report))
        Toast.makeText(this, "تم نسخ تقرير التحليل كاملًا", Toast.LENGTH_SHORT).show()
    }

    private fun runManualCheck() {
        val request = OneTimeWorkRequestBuilder<CheckWorker>()
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            CheckWorker.MANUAL_WORK,
            ExistingWorkPolicy.KEEP,
            request
        )
        Toast.makeText(this, "بدأ الفحص؛ انتظر ظهور نتيجة القراءة", Toast.LENGTH_LONG).show()
    }

    private fun startMonitoring() {
        val request = PeriodicWorkRequestBuilder<CheckWorker>(15, TimeUnit.MINUTES)
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            CheckWorker.PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
        prefs.edit().putBoolean("monitoring", true).apply()
        // نفّذ قراءة تأسيسية فورًا بدل انتظار أول دورة كاملة (15 دقيقة).
        val initialCheck = OneTimeWorkRequestBuilder<CheckWorker>()
            .setConstraints(networkConstraints())
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork(
            CheckWorker.MANUAL_WORK,
            ExistingWorkPolicy.KEEP,
            initialCheck
        )
        Toast.makeText(this, "تم تفعيل المراقبة وبدء فحص تأسيسي", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun stopMonitoring() {
        WorkManager.getInstance(this).cancelUniqueWork(CheckWorker.PERIODIC_WORK)
        prefs.edit().putBoolean("monitoring", false).apply()
        Toast.makeText(this, "تم إيقاف المراقبة الدورية", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun loadSavedNumbers(): List<String> {
        val prefix = modePrefix()
        if (!prefs.getBoolean("${prefix}_saved_list_complete", false)) return emptyList()
        val stored = prefs.getString("${prefix}_numbers_json", null)
        if (!stored.isNullOrBlank()) {
            return try {
                val array = JSONArray(stored)
                (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }
            } catch (_: Exception) {
                emptyList()
            }
        }
        return prefs.getStringSet("${prefix}_numbers", emptySet())?.toList()?.sorted().orEmpty()
    }

    private fun normalizeDigits(value: String): String = buildString {
        value.forEach { ch ->
            val normalized = when (ch) {
                in '\u0660'..'\u0669' -> ('0'.code + ch.code - '\u0660'.code).toChar()
                in '\u06F0'..'\u06F9' -> ('0'.code + ch.code - '\u06F0'.code).toChar()
                else -> ch
            }
            if (normalized in '0'..'9') append(normalized)
        }
    }

    private fun searchSavedNumbers() {
        if (!prefs.getBoolean("${modePrefix()}_saved_list_complete", false)) {
            latestSearchResults = emptyList()
            numberResults.text = "لا يمكن البحث في ${modeLabel(selectedSimMode)} الآن؛ لم تُحفظ قائمة مكتملة لهذا النوع بعد."
            return
        }
        val query = normalizeDigits(numberQuery.text?.toString().orEmpty())
        if (query.length < 2) {
            latestSearchResults = emptyList()
            numberResults.text = "أدخل رقمين على الأقل لتضييق النتائج."
            return
        }
        val numbers = loadSavedNumbers()
        latestSearchResults = numbers.filter { it.contains(query) }
        numberResults.text = if (latestSearchResults.isEmpty()) {
            "لا توجد أرقام تحتوي على التسلسل $query."
        } else {
            val visible = latestSearchResults.take(MAX_VISIBLE_SEARCH_RESULTS)
            "${modeLabel(selectedSimMode)} — عدد النتائج: ${latestSearchResults.size}\n" +
                visible.joinToString("\n") +
                if (latestSearchResults.size > visible.size) "\n\nيُعرض أول ${visible.size} فقط؛ زر النسخ ينسخ جميع النتائج." else ""
        }
        numberResults.textDirection = View.TEXT_DIRECTION_LTR
    }

    private fun chooseRandomNumber() {
        if (!prefs.getBoolean("${modePrefix()}_saved_list_complete", false)) {
            latestSearchResults = emptyList()
            numberResults.text = "لا يمكن اختيار رقم عشوائي؛ لا توجد قائمة مكتملة محفوظة لـ${modeLabel(selectedSimMode)} بعد."
            return
        }
        val numbers = loadSavedNumbers()
        val selected = numbers.randomOrNull()
        if (selected == null) {
            latestSearchResults = emptyList()
            numberResults.text = "القائمة المحفوظة لا تحتوي على أرقام قابلة للاختيار."
            return
        }
        latestSearchResults = listOf(selected)
        val savedAt = prefs.getLong("${modePrefix()}_number_updated_time", 0L)
        numberResults.text = "اقتراح عشوائي من قائمة ${modeLabel(selectedSimMode)} المحفوظة:\n$selected\n\nتاريخ القائمة: ${if (savedAt > 0L) formatDate(savedAt) else "غير معروف"}\nهذا اختيار عشوائي محلي؛ لا يحجز الرقم ولا يؤكد توافره الحالي عند فودافون."
        numberResults.textDirection = View.TEXT_DIRECTION_LTR
    }

    private fun copySearchResults() {
        if (latestSearchResults.isEmpty()) {
            Toast.makeText(this, "لا توجد نتائج لنسخها", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Vodafone RED search results", latestSearchResults.joinToString("\n")))
        Toast.makeText(this, "تم نسخ ${latestSearchResults.size} رقمًا", Toast.LENGTH_SHORT).show()
    }

    private fun openVodafonePage() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(CheckWorker.PAGE)))
        } catch (_: Exception) {
            Toast.makeText(this, "تعذّر فتح صفحة فودافون", Toast.LENGTH_LONG).show()
        }
    }

    private fun networkConstraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    private fun requestNotificationPermissionIfNeeded() {
        if (
            Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                NOTIFICATION_PERMISSION_REQUEST
            )
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    }

    private fun sectionTitle(text: String) = label(text, 17, Color.rgb(35, 40, 48), true)

    private fun actionButton(text: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setTextColor(if (primary) Color.WHITE else Color.rgb(175, 20, 40))
        if (Build.VERSION.SDK_INT >= 21) {
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                if (primary) Color.rgb(210, 25, 45) else Color.WHITE
            )
        }
        setOnClickListener { action() }
    }

    private fun topMargin(value: Int) = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = dp(value)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun formatDate(time: Long) = SimpleDateFormat(
        "dd/MM/yyyy  HH:mm:ss",
        Locale.getDefault()
    ).format(Date(time))

    override fun onResume() {
        super.onResume()
        prefs.registerOnSharedPreferenceChangeListener(listener)
        render()
    }

    override fun onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
        super.onPause()
    }

    companion object {
        private const val NOTIFICATION_PERMISSION_REQUEST = 100
        private const val MAX_VISIBLE_SEARCH_RESULTS = 100
    }
}
