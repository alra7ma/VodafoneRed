package com.example.vfwatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Pure Java implementation of the 22-Nov-2026 Vodafone RED number-composition standard.
 * Phone numbers remain strings throughout; numeric conversion is used only for §8 deltas.
 */
public final class SpecialNumberAnalyzer {
    private static final Set<String> REFERENCE_UNITS;
    private static final Set<String> ASCENDING_SUFFIXES;

    static {
        LinkedHashSet<String> units = new LinkedHashSet<>();
        units.addAll(Arrays.asList("010", "0100", "01000"));
        units.addAll(Arrays.asList("0", "1", "2", "3", "4", "5", "6", "7", "8", "9"));
        units.addAll(Arrays.asList(
                "00", "99", "90", "88", "80", "77", "70", "66", "60", "55", "50",
                "44", "40", "33", "30", "22", "20", "19", "18", "17", "16", "15",
                "14", "13", "12", "11", "10"));
        units.addAll(Arrays.asList(
                "000", "999", "900", "888", "800", "777", "700", "666", "600", "555",
                "500", "444", "400", "333", "300", "222", "200", "111", "100"));
        units.addAll(Arrays.asList(
                "8000", "7777", "7000", "6666", "6000", "5555", "5000", "4444", "4000",
                "3333", "3000", "2222", "2000", "1111", "1000", "0000", "9999", "9000", "8888"));
        units.addAll(Arrays.asList(
                "99999", "88888", "77777", "66666", "55555", "44444", "33333", "22222", "11111", "00000"));
        units.addAll(Arrays.asList(
                "999999", "888888", "777777", "666666", "555555", "444444", "333333", "222222", "111111", "000000"));
        if (units.size() != 98) throw new IllegalStateException("Reference repository must contain exactly 98 units; found " + units.size());
        REFERENCE_UNITS = Collections.unmodifiableSet(units);

        LinkedHashSet<String> ascending = new LinkedHashSet<>();
        ascending.addAll(Arrays.asList("0123", "1234", "2345", "3456", "4567", "5678", "6789"));
        ascending.addAll(Arrays.asList("01234", "12345", "23456", "34567", "45678", "56789"));
        ASCENDING_SUFFIXES = Collections.unmodifiableSet(ascending);
    }

    private SpecialNumberAnalyzer() { }

    public static final class Relation {
        public final String type;
        public final List<String> members;
        public final List<Long> differences;

        Relation(String type, List<String> members, List<Long> differences) {
            this.type = type;
            this.members = Collections.unmodifiableList(new ArrayList<>(members));
            this.differences = Collections.unmodifiableList(new ArrayList<>(differences));
        }
    }

    public static final class NumberRecord {
        public final String number;
        public final int firstAppearance;
        public final List<List<String>> p3;
        public final List<List<String>> p4;
        public final List<List<String>> p5;
        public final List<Integer> matchingPatterns;
        public final boolean referenceAccepted;
        public final boolean patternAccepted;
        public final String acceptancePath;
        public final int group;
        public final int item;

        NumberRecord(String number, int firstAppearance, List<List<String>> p3,
                     List<List<String>> p4, List<List<String>> p5,
                     List<Integer> matchingPatterns, boolean referenceAccepted,
                     boolean patternAccepted, String acceptancePath, int group, int item) {
            this.number = number;
            this.firstAppearance = firstAppearance;
            this.p3 = immutableNested(p3);
            this.p4 = immutableNested(p4);
            this.p5 = immutableNested(p5);
            this.matchingPatterns = Collections.unmodifiableList(new ArrayList<>(matchingPatterns));
            this.referenceAccepted = referenceAccepted;
            this.patternAccepted = patternAccepted;
            this.acceptancePath = acceptancePath;
            this.group = group;
            this.item = item;
        }

        public int partitionCount() { return p3.size() + p4.size() + p5.size(); }

        private static List<List<String>> immutableNested(List<List<String>> source) {
            List<List<String>> copy = new ArrayList<>();
            for (List<String> row : source) copy.add(Collections.unmodifiableList(new ArrayList<>(row)));
            return Collections.unmodifiableList(copy);
        }
    }

    public static final class Analysis {
        public final int rawOccurrences;
        public final int uniqueNumbers;
        public final int acceptedNumbers;
        public final int excludedNumbers;
        public final int referenceOnly;
        public final int patternOnly;
        public final int dualAccepted;
        public final int totalPartitions;
        public final boolean rawOccurrenceCountKnown;
        public final List<NumberRecord> accepted;
        public final List<Relation> plusOneChains;
        public final List<Relation> plusOnePairs;
        public final List<Relation> plusTenChains;
        public final Map<String, Integer> itemCounts;
        public final String report;

        Analysis(int rawOccurrences, int uniqueNumbers, int acceptedNumbers, int excludedNumbers,
                 int referenceOnly, int patternOnly, int dualAccepted, int totalPartitions,
                 boolean rawOccurrenceCountKnown, List<NumberRecord> accepted,
                 List<Relation> plusOneChains, List<Relation> plusOnePairs,
                 List<Relation> plusTenChains, Map<String, Integer> itemCounts, String report) {
            this.rawOccurrences = rawOccurrences;
            this.uniqueNumbers = uniqueNumbers;
            this.acceptedNumbers = acceptedNumbers;
            this.excludedNumbers = excludedNumbers;
            this.referenceOnly = referenceOnly;
            this.patternOnly = patternOnly;
            this.dualAccepted = dualAccepted;
            this.totalPartitions = totalPartitions;
            this.rawOccurrenceCountKnown = rawOccurrenceCountKnown;
            this.accepted = Collections.unmodifiableList(new ArrayList<>(accepted));
            this.plusOneChains = Collections.unmodifiableList(new ArrayList<>(plusOneChains));
            this.plusOnePairs = Collections.unmodifiableList(new ArrayList<>(plusOnePairs));
            this.plusTenChains = Collections.unmodifiableList(new ArrayList<>(plusTenChains));
            this.itemCounts = Collections.unmodifiableMap(new LinkedHashMap<>(itemCounts));
            this.report = report;
        }
    }

    /** Analyze an ordered number list and, when available, its raw paragraph occurrences. */
    public static Analysis analyze(List<String> sourceNumbers, List<String> rawOccurrences, String listLabel) {
        LinkedHashMap<String, Integer> firstPositions = new LinkedHashMap<>();
        if (sourceNumbers != null) {
            for (int i = 0; i < sourceNumbers.size(); i++) {
                String value = sourceNumbers.get(i);
                if (isTargetNumber(value) && !firstPositions.containsKey(value)) firstPositions.put(value, i + 1);
            }
        }

        List<NumberRecord> accepted = new ArrayList<>();
        int refOnly = 0, patternOnly = 0, dual = 0, partitionsTotal = 0;
        LinkedHashMap<String, Integer> itemCounts = new LinkedHashMap<>();
        int excluded = 0;

        for (Map.Entry<String, Integer> entry : firstPositions.entrySet()) {
            String number = entry.getKey();
            List<List<String>> p3 = partitions(number, 3);
            List<List<String>> p4 = partitions(number, 4);
            List<List<String>> p5 = partitions(number, 5);
            List<Integer> patterns = matchingPatterns(number);
            boolean ref = !p3.isEmpty() || !p4.isEmpty() || !p5.isEmpty();
            boolean pat = !patterns.isEmpty();
            if (!ref && !pat) { excluded++; continue; }

            String path = ref && pat ? "مزدوج" : ref ? "مرجعي فقط" : "نمطي فقط";
            if ("مرجعي فقط".equals(path)) refOnly++;
            else if ("نمطي فقط".equals(path)) patternOnly++;
            else dual++;

            int[] classification = classify(p3, p4, p5, patterns);
            if (classification[0] == 0) throw new IllegalStateException("Accepted number has no category: " + number);
            String key = itemKey(classification[0], classification[1]);
            itemCounts.put(key, itemCounts.containsKey(key) ? itemCounts.get(key) + 1 : 1);
            partitionsTotal += p3.size() + p4.size() + p5.size();
            accepted.add(new NumberRecord(number, entry.getValue(), p3, p4, p5, patterns,
                    ref, pat, path, classification[0], classification[1]));
        }

        Collections.sort(accepted, new Comparator<NumberRecord>() {
            @Override public int compare(NumberRecord a, NumberRecord b) {
                if (a.group != b.group) return Integer.compare(a.group, b.group);
                if (a.item != b.item) return Integer.compare(a.item, b.item);
                return Integer.compare(a.firstAppearance, b.firstAppearance);
            }
        });

        List<String> acceptedNumbers = new ArrayList<>();
        for (NumberRecord record : accepted) acceptedNumbers.add(record.number);
        List<Relation> plusOneChains = findMaximalChains(acceptedNumbers, 1L, 3, "سلسلة بفارق 1");
        List<Relation> plusOnePairs = findAdjacentPairs(acceptedNumbers, 1L);
        List<Relation> plusTenChains = findMaximalChains(acceptedNumbers, 10L, 2, "علاقة بفارق 10");

        boolean rawKnown = rawOccurrences != null;
        int rawCount = firstPositions.size();
        if (rawKnown) {
            rawCount = 0;
            for (String occurrence : rawOccurrences) if (isTargetNumber(occurrence)) rawCount++;
        }
        String report = buildReport(listLabel, rawCount, rawKnown, firstPositions.size(), excluded,
                refOnly, patternOnly, dual, partitionsTotal, accepted, itemCounts,
                plusOneChains, plusOnePairs, plusTenChains);
        return new Analysis(rawCount, firstPositions.size(), accepted.size(), excluded,
                refOnly, patternOnly, dual, partitionsTotal, rawKnown, accepted,
                plusOneChains, plusOnePairs, plusTenChains, itemCounts, report);
    }

    public static int referenceUnitCount() { return REFERENCE_UNITS.size(); }

    public static List<Integer> matchingPatterns(String number) {
        if (!isTargetNumber(number)) return Collections.emptyList();
        List<Integer> matches = new ArrayList<>();
        // 1: 010000ABCDE
        if (number.startsWith("010000")) matches.add(1);
        // 2: 010ABCDABCD
        if (number.substring(3, 7).equals(number.substring(7, 11))) matches.add(2);
        // 3: 010ABABCDCD
        if (number.charAt(3) == number.charAt(5) && number.charAt(4) == number.charAt(6)
                && number.charAt(7) == number.charAt(9) && number.charAt(8) == number.charAt(10)) matches.add(3);
        // 4: 010AABBCCDD
        if (number.charAt(3) == number.charAt(4) && number.charAt(5) == number.charAt(6)
                && number.charAt(7) == number.charAt(8) && number.charAt(9) == number.charAt(10)) matches.add(4);
        // 5: 010ABCDDCBA
        if (number.charAt(3) == number.charAt(10) && number.charAt(4) == number.charAt(9)
                && number.charAt(5) == number.charAt(8) && number.charAt(6) == number.charAt(7)) matches.add(5);
        // 6: 010ABCBA010
        if (number.endsWith("010") && number.charAt(3) == number.charAt(7)
                && number.charAt(4) == number.charAt(6)) matches.add(6);
        // 7: ascending final 4 or 5 digits.
        if (ASCENDING_SUFFIXES.contains(number.substring(7)) || ASCENDING_SUFFIXES.contains(number.substring(6))) matches.add(7);
        return Collections.unmodifiableList(matches);
    }

    public static List<List<String>> referencePartitions(String number, int unitCount) {
        if (!isTargetNumber(number) || unitCount < 3 || unitCount > 5) return Collections.emptyList();
        return immutablePartitions(partitions(number, unitCount));
    }

    public static boolean isTargetNumber(String value) {
        if (value == null || value.length() != 11 || !value.startsWith("010")) return false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c < '0' || c > '9') return false;
        }
        return true;
    }

    private static List<List<String>> partitions(String number, int unitCount) {
        List<List<String>> found = new ArrayList<>();
        buildPartitions(number, 0, unitCount, new ArrayList<String>(), found);
        Collections.sort(found, new Comparator<List<String>>() {
            @Override public int compare(List<String> a, List<String> b) {
                int pa = 0, pb = 0;
                for (int i = 0; i < a.size() - 1; i++) {
                    pa += a.get(i).length(); pb += b.get(i).length();
                    if (pa != pb) return Integer.compare(pa, pb);
                }
                return 0;
            }
        });
        return found;
    }

    private static void buildPartitions(String number, int position, int targetCount,
                                        List<String> current, List<List<String>> found) {
        if (current.size() == targetCount) {
            if (position == number.length()) found.add(new ArrayList<>(current));
            return;
        }
        if (position >= number.length()) return;
        int remainingSlots = targetCount - current.size();
        if (number.length() - position < remainingSlots) return;
        for (String unit : REFERENCE_UNITS) {
            if (number.startsWith(unit, position)) {
                current.add(unit);
                buildPartitions(number, position + unit.length(), targetCount, current, found);
                current.remove(current.size() - 1);
            }
        }
    }

    private static int[] classify(List<List<String>> p3, List<List<String>> p4,
                                  List<List<String>> p5, List<Integer> patterns) {
        // Group 1, in exact priority order.
        if (!p3.isEmpty()) return new int[]{1, 1};
        if (!p4.isEmpty()) return new int[]{1, 2};
        if (patterns.contains(4)) return new int[]{1, 3};
        if (hasUnitLength(p5, 5)) return new int[]{1, 4};
        if (hasAdjacentUnits(p5, 3)) return new int[]{1, 5};
        if (hasLastUnitLength(p5, 4)) return new int[]{1, 6};
        // Group 2, in exact priority order.
        if (hasUnitLength(p5, 4)) return new int[]{2, 1};
        if (hasNonAdjacentUnits(p5, 3)) return new int[]{2, 2};
        if (!p5.isEmpty()) return new int[]{2, 3};
        if (patterns.contains(7)) return new int[]{2, 4};
        if (patterns.contains(1)) return new int[]{2, 5};
        // Group 3, in exact priority order.
        if (patterns.contains(3)) return new int[]{3, 1};
        if (patterns.contains(2)) return new int[]{3, 2};
        if (patterns.contains(6)) return new int[]{3, 3};
        if (patterns.contains(5)) return new int[]{3, 4};
        return new int[]{0, 0};
    }

    private static boolean hasUnitLength(List<List<String>> partitions, int length) {
        for (List<String> partition : partitions)
            for (String unit : partition) if (unit.length() == length) return true;
        return false;
    }

    private static boolean hasLastUnitLength(List<List<String>> partitions, int length) {
        for (List<String> partition : partitions)
            if (!partition.isEmpty() && partition.get(partition.size() - 1).length() == length) return true;
        return false;
    }

    private static boolean hasAdjacentUnits(List<List<String>> partitions, int length) {
        for (List<String> partition : partitions)
            for (int i = 0; i + 1 < partition.size(); i++)
                if (partition.get(i).length() == length && partition.get(i + 1).length() == length) return true;
        return false;
    }

    private static boolean hasNonAdjacentUnits(List<List<String>> partitions, int length) {
        for (List<String> partition : partitions) {
            for (int i = 0; i < partition.size(); i++) {
                if (partition.get(i).length() != length) continue;
                for (int j = i + 2; j < partition.size(); j++)
                    if (partition.get(j).length() == length) return true;
            }
        }
        return false;
    }

    private static String itemKey(int group, int item) { return "المجموعة " + group + " — البند " + item; }

    private static List<Relation> findMaximalChains(List<String> numbers, long step, int minimumSize, String label) {
        TreeSet<Long> values = new TreeSet<>();
        Map<Long, String> original = new HashMap<>();
        for (String number : numbers) {
            long value = Long.parseLong(number);
            values.add(value);
            original.put(value, number);
        }
        List<Relation> result = new ArrayList<>();
        for (Long value : values) {
            if (values.contains(value - step)) continue;
            List<Long> chain = new ArrayList<>();
            long cursor = value;
            while (values.contains(cursor)) {
                chain.add(cursor);
                cursor += step;
            }
            if (chain.size() >= minimumSize) {
                List<String> members = new ArrayList<>();
                List<Long> deltas = new ArrayList<>();
                for (Long member : chain) members.add(original.get(member));
                for (int i = 1; i < chain.size(); i++) deltas.add(step);
                result.add(new Relation(label, members, deltas));
            }
        }
        Collections.sort(result, new Comparator<Relation>() {
            @Override public int compare(Relation a, Relation b) {
                return Long.compare(Long.parseLong(a.members.get(0)), Long.parseLong(b.members.get(0)));
            }
        });
        return result;
    }

    private static List<Relation> findAdjacentPairs(List<String> numbers, long step) {
        TreeSet<Long> values = new TreeSet<>();
        Map<Long, String> original = new HashMap<>();
        for (String number : numbers) {
            long value = Long.parseLong(number);
            values.add(value);
            original.put(value, number);
        }
        List<Relation> result = new ArrayList<>();
        for (Long value : values) {
            if (values.contains(value + step)) {
                result.add(new Relation("زوج بفارق 1",
                        Arrays.asList(original.get(value), original.get(value + step)),
                        Collections.singletonList(step)));
            }
        }
        return result;
    }

    private static String buildReport(String listLabel, int rawCount, boolean rawKnown,
                                      int uniqueCount, int excluded, int refOnly, int patternOnly,
                                      int dual, int partitionCount, List<NumberRecord> accepted,
                                      Map<String, Integer> itemCounts, List<Relation> plusOneChains,
                                      List<Relation> plusOnePairs, List<Relation> plusTenChains) {
        StringBuilder out = new StringBuilder(8192);
        out.append("نتيجة تطبيق المواصفة على قائمة فودافون RED — ")
                .append(listLabel == null || listLabel.trim().isEmpty() ? "القائمة المحفوظة" : listLabel.trim())
                .append("\n");
        out.append("نسخة المواصفة: 22 نوفمبر 2026\n\n");
        out.append("1. الأرقام المستخرجة والمقبولة والنتائج النهائية\n");
        out.append("الجدول 1 — الإحصاءات العامة\n");
        stat(out, "الظهورات الخام من عناصر <p>", rawCount);
        stat(out, "الأرقام الفريدة", uniqueCount);
        stat(out, "الأرقام المقبولة", accepted.size());
        stat(out, "الأرقام المستبعدة", excluded);
        if (!rawKnown) out.append("ملاحظة: عدد الظهورات الخام التاريخي غير محفوظ؛ عُرض عدد الأرقام الفريدة بدلًا منه كتقدير أدنى.\n");
        else if (rawCount < uniqueCount) out.append("تنبيه اتساق: عدد الظهورات الخام أقل من عدد الأرقام الفريدة؛ راجع مصدر القائمة قبل الاعتماد على هذا التقرير.\n");
        out.append("\nالجدول 2 — مسارات القبول\n");
        stat(out, "مرجعي فقط", refOnly);
        stat(out, "نمطي فقط", patternOnly);
        stat(out, "مزدوج", dual);
        stat(out, "إجمالي المقبولين", accepted.size());
        out.append("\nالجدول 3 — المقبولون بحسب المجموعة\n");
        for (int group = 1; group <= 3; group++) {
            int count = 0;
            for (NumberRecord record : accepted) if (record.group == group) count++;
            if (count > 0) stat(out, "المجموعة " + group, count);
        }
        stat(out, "إجمالي المجموعات 1–3", accepted.size());
        out.append("\nالجدول 4 — المقبولون بحسب البنود\n");
        for (int group = 1; group <= 3; group++) {
            int maxItem = group == 1 ? 6 : group == 2 ? 5 : 4;
            for (int item = 1; item <= maxItem; item++) {
                String key = itemKey(group, item);
                Integer count = itemCounts.get(key);
                if (count != null && count > 0) stat(out, key, count);
            }
        }
        out.append("\nالجدول 5 — علاقات المجموعة الرابعة\n");
        stat(out, "سلاسل بفارق 1 (ثلاثة أعضاء فأكثر)", plusOneChains.size());
        stat(out, "أزواج بفارق 1", plusOnePairs.size());
        stat(out, "علاقات بفارق 10 (عضوان فأكثر)", plusTenChains.size());
        stat(out, "إجمالي العلاقات", plusOneChains.size() + plusOnePairs.size() + plusTenChains.size());

        out.append("\n2. سجل الأرقام المقبولة\n");
        int currentGroup = 0, currentItem = 0, itemNumbers = 0, itemPartitions = 0;
        for (NumberRecord record : accepted) {
            if (record.group != currentGroup || record.item != currentItem) {
                if (itemNumbers > 0) {
                    out.append("إجمالي أرقام البند: ").append(itemNumbers)
                            .append("؛ عدد التقسيمات المرجعية الصحيحة: ").append(itemPartitions).append("\n\n");
                }
                currentGroup = record.group;
                currentItem = record.item;
                itemNumbers = 0;
                itemPartitions = 0;
                out.append("المجموعة ").append(currentGroup).append(" — البند ").append(currentItem).append("\n");
                out.append(itemTitle(currentGroup, currentItem)).append("\n");
            }
            itemNumbers++;
            itemPartitions += record.partitionCount();
            out.append(record.number);
            if (!record.matchingPatterns.isEmpty()) out.append(" — الأنماط المطابقة: ").append(patternLabels(record.matchingPatterns));
            if (!record.p3.isEmpty() || !record.p4.isEmpty() || !record.p5.isEmpty()) {
                out.append("\n");
                appendPartitions(out, record.p3);
                appendPartitions(out, record.p4);
                appendPartitions(out, record.p5);
            }
            out.append("\n");
        }
        if (itemNumbers > 0) {
            out.append("إجمالي أرقام البند: ").append(itemNumbers)
                    .append("؛ عدد التقسيمات المرجعية الصحيحة: ").append(itemPartitions).append("\n");
        }
        if (accepted.isEmpty()) out.append("لا توجد أرقام مقبولة وفق المواصفة.\n");

        out.append("\n3. المجموعة الرابعة وتقسيماتها\n");
        appendRelations(out, "1. سلاسل بفارق 1 (k ≥ 3)", plusOneChains);
        appendRelations(out, "2. أزواج بفارق 1", plusOnePairs);
        appendRelations(out, "3. علاقات بفارق 10 (k ≥ 2)", plusTenChains);

        out.append("\n4. النتيجة النهائية\n");
        out.append("الأرقام الفريدة: ").append(uniqueCount)
                .append("؛ المقبولة: ").append(accepted.size())
                .append("؛ المستبعدة: ").append(excluded)
                .append("؛ مرجعي فقط: ").append(refOnly)
                .append("؛ نمطي فقط: ").append(patternOnly)
                .append("؛ مزدوج: ").append(dual)
                .append("؛ إجمالي التقسيمات المرجعية الصحيحة: ").append(partitionCount)
                .append("؛ علاقات المجموعة الرابعة: ")
                .append(plusOneChains.size() + plusOnePairs.size() + plusTenChains.size()).append(".\n");
        return out.toString();
    }

    private static void stat(StringBuilder out, String label, int value) {
        out.append(label).append(": ").append(value).append("\n");
    }

    private static String itemTitle(int group, int item) {
        if (group == 1) {
            switch (item) {
                case 1: return "وجود تقسيم صحيح من 3 وحدات (P₃).";
                case 2: return "وجود تقسيم صحيح من 4 وحدات (P₄).";
                case 3: return "النمط 4 — 010AABBCCDD.";
                case 4: return "تقسيم من 5 وحدات فيه وحدة خماسية.";
                case 5: return "تقسيم من 5 وحدات فيه وحدتان ثلاثيتان متجاورتان.";
                case 6: return "تقسيم من 5 وحدات وحدته الأخيرة رباعية.";
            }
        } else if (group == 2) {
            switch (item) {
                case 1: return "تقسيم من 5 وحدات فيه وحدة رباعية.";
                case 2: return "تقسيم من 5 وحدات فيه وحدتان ثلاثيتان غير متجاورتين.";
                case 3: return "بقية الأرقام التي لها P₅.";
                case 4: return "النمط 7 — نهاية تصاعدية.";
                case 5: return "النمط 1 — 010000ABCDE.";
            }
        } else if (group == 3) {
            switch (item) {
                case 1: return "النمط 3 — 010ABABCDCD.";
                case 2: return "النمط 2 — 010ABCDABCD.";
                case 3: return "النمط 6 — 010ABCBA010.";
                case 4: return "النمط 5 — 010ABCDDCBA.";
            }
        }
        return "";
    }

    private static String patternLabels(List<Integer> patterns) {
        List<String> labels = new ArrayList<>();
        for (Integer pattern : patterns) {
            switch (pattern) {
                case 1: labels.add("1 (010000ABCDE)"); break;
                case 2: labels.add("2 (010ABCDABCD)"); break;
                case 3: labels.add("3 (010ABABCDCD)"); break;
                case 4: labels.add("4 (010AABBCCDD)"); break;
                case 5: labels.add("5 (010ABCDDCBA)"); break;
                case 6: labels.add("6 (010ABCBA010)"); break;
                case 7: labels.add("7 (نهاية تصاعدية)"); break;
                default: labels.add(String.valueOf(pattern)); break;
            }
        }
        return joinStrings(labels, "، ");
    }

    private static void appendPartitions(StringBuilder out, List<List<String>> partitions) {
        for (List<String> partition : partitions) {
            out.append("  ").append(joinStrings(partition, " + ")).append("\n");
        }
    }

    private static void appendRelations(StringBuilder out, String heading, List<Relation> relations) {
        out.append(heading).append("\n");
        if (relations.isEmpty()) {
            out.append("لا يوجد\n");
            return;
        }
        int index = 1;
        for (Relation relation : relations) {
            out.append(index++).append(". ")
                    .append(joinStrings(relation.members, " → "))
                    .append(" — عدد الأعضاء: ").append(relation.members.size())
                    .append("؛ الفوارق المتتالية: ").append(joinLongs(relation.differences)).append("\n");
        }
    }

    private static String joinLongs(List<Long> values) {
        List<String> strings = new ArrayList<>();
        for (Long value : values) strings.add(String.valueOf(value));
        return joinStrings(strings, "، ");
    }

    private static String joinStrings(List<String> values, String separator) {
        StringBuilder joined = new StringBuilder();
        for (String value : values) {
            if (joined.length() > 0) joined.append(separator);
            joined.append(value);
        }
        return joined.toString();
    }

    private static List<List<String>> immutablePartitions(List<List<String>> source) {
        List<List<String>> result = new ArrayList<>();
        for (List<String> row : source) result.add(Collections.unmodifiableList(new ArrayList<>(row)));
        return Collections.unmodifiableList(result);
    }
}
