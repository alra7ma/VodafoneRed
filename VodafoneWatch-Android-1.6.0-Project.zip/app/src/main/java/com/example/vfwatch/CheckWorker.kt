package com.example.vfwatch

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

class CheckWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {

    override suspend fun doWork(): Result {
        val result = withTimeoutOrNull(SCRAPE_TIMEOUT_MS) {
            withContext(Dispatchers.Main.immediate) { scrape() }
        }

        if (result == null) {
            saveFailure("انتهت مهلة انتظار تحميل صفحة فودافون أو التبديل بين نوعي الخطوط")
            return Result.retry()
        }

        val pageError = result.optString("error", "").trim()
        if (pageError.isNotEmpty()) {
            saveFailure(pageError)
            return Result.retry()
        }

        val modeArray = result.optJSONArray("modes") ?: JSONArray().put(result)
        if (modeArray.length() == 0) {
            saveFailure("لم تُقرأ بيانات أي نوع من أنواع خطوط RED")
            return Result.retry()
        }

        val warningsArray = result.optJSONArray("warnings") ?: JSONArray()
        val warningsText = (0 until warningsArray.length()).map { warningsArray.optString(it) }.filter { it.isNotBlank() }.joinToString(" | ")
        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val changes = mutableListOf<String>()
        val historyModes = JSONArray()
        val editor = preferences.edit()
        var successfulModes = 0
        var primaryResult: JSONObject? = null

        for (index in 0 until modeArray.length()) {
            val item = modeArray.optJSONObject(index) ?: continue
            val simType = item.optString("simType", "unknown").lowercase()
            if (simType !in setOf("physical", "esim", "unknown")) continue

            val count = item.optInt("count", -1)
            val loaded = item.optInt("loaded", -1)
            val total = item.optInt("total", -1)
            val counterMode = item.optString("counterMode", item.optString("mode", "single"))
            val source = item.optString("source", "غير محدد")
            if (count < 0 || loaded < 0 || total < 0) continue

            val numberArray = item.optJSONArray("numbers") ?: JSONArray()
            val rawNumberArray = item.optJSONArray("rawNumbers") ?: numberArray
            val rawOccurrences = ArrayList<String>()
            val numbers = LinkedHashSet<String>()
            for (i in 0 until rawNumberArray.length()) {
                val number = rawNumberArray.optString(i).filter(Char::isDigit)
                if (Regex("^01[0125]\\d{8}$").matches(number)) {
                    rawOccurrences.add(number)
                    numbers.add(number)
                }
            }
            // Older extractor payloads may only provide the unique list.
            if (rawOccurrences.isEmpty() && numberArray.length() > 0) {
                for (i in 0 until numberArray.length()) {
                    val number = numberArray.optString(i).filter(Char::isDigit)
                    if (Regex("^01[0125]\\d{8}$").matches(number)) {
                        rawOccurrences.add(number)
                        numbers.add(number)
                    }
                }
            }

            val numberCardsCount = item.optInt("numberCardsCount", -1)
            val listSource = item.optString("listSource", "غير محدد")
            val prefix = "mode_$simType"
            val oldCount = preferences.getInt("${prefix}_count", -1)
            val oldLoaded = preferences.getInt("${prefix}_loaded", -1)
            val oldTotal = preferences.getInt("${prefix}_total", -1)
            val oldCounterMode = preferences.getString("${prefix}_counter_mode", "single") ?: "single"
            val oldNumbers = preferences.getStringSet("${prefix}_numbers", emptySet())?.toSet() ?: emptySet()
            val oldListComplete = preferences.getBoolean("${prefix}_saved_list_complete", false)

            val completeNumberList = item.optBoolean("numbersComplete", false) &&
                counterMode == "pair" && total > 0 && loaded == total &&
                numberCardsCount == loaded && rawOccurrences.size == loaded && numbers.size == loaded
            val canCompareLists = completeNumberList && oldListComplete && oldNumbers.isNotEmpty()
            val addedNumbers = if (canCompareLists) numbers.filter { it !in oldNumbers } else emptyList()
            val removedNumbers = if (canCompareLists) oldNumbers.filter { it !in numbers } else emptyList()
            val simLabel = when (simType) {
                "physical" -> "SIM Card"
                "esim" -> "eSIM"
                else -> "نوع الشريحة غير محدد"
            }
            val price = item.optString("price", "").trim()

            if (oldCount >= 0) {
                val countChanged = if (counterMode == "pair" && oldCounterMode == "pair") {
                    oldLoaded != loaded || oldTotal != total
                } else oldCount != count
                if (countChanged) {
                    changes.add("$simLabel — تغيّر العداد: ${if (counterMode == "pair") "$loaded / $total" else count.toString()}")
                }
            }
            if (addedNumbers.isNotEmpty()) {
                changes.add("$simLabel — أرقام جديدة (+${addedNumbers.size}): ${addedNumbers.take(6).joinToString("، ")}")
            }
            if (removedNumbers.isNotEmpty()) {
                changes.add("$simLabel — أرقام لم تعد ظاهرة (-${removedNumbers.size}): ${removedNumbers.take(6).joinToString("، ")}")
            }

            editor.putInt("${prefix}_count", count)
                .putInt("${prefix}_loaded", loaded)
                .putInt("${prefix}_total", total)
                .putString("${prefix}_counter_mode", counterMode)
                .putString("${prefix}_source", source)
                .putString("${prefix}_price", price)
                .putLong("${prefix}_time", now)
                .putBoolean("${prefix}_last_ok", true)
                .putInt("${prefix}_number_count", numbers.size)
                .putInt("${prefix}_number_cards_count", numberCardsCount)
                .putString("${prefix}_list_source", listSource)
                .putBoolean("${prefix}_list_complete", completeNumberList)

            if (completeNumberList) {
                val numbersJson = JSONArray().apply { numbers.forEach { put(it) } }.toString()
                val rawOccurrencesJson = JSONArray().apply { rawOccurrences.forEach { put(it) } }.toString()
                val analysis = SpecialNumberAnalyzer.analyze(numbers.toList(), rawOccurrences, simLabel)
                val currentSpecialNumbers = analysis.accepted.map { it.number }.toSet()
                val oldSpecialNumbers = preferences.getStringSet("${prefix}_special_numbers", emptySet())?.toSet() ?: emptySet()
                val newlySpecialNumbers = if (canCompareLists) addedNumbers.filter { it in currentSpecialNumbers } else emptyList()
                val removedSpecialNumbers = if (canCompareLists) removedNumbers.filter { it in oldSpecialNumbers } else emptyList()

                editor.putStringSet("${prefix}_numbers", numbers.toMutableSet())
                    .putString("${prefix}_numbers_json", numbersJson)
                    .putString("${prefix}_raw_occurrences_json", rawOccurrencesJson)
                    .putInt("${prefix}_raw_occurrences_count", rawOccurrences.size)
                    .putInt("${prefix}_saved_number_count", numbers.size)
                    .putLong("${prefix}_number_updated_time", now)
                    .putBoolean("${prefix}_saved_list_complete", true)
                    .putString("${prefix}_analysis_report", analysis.report)
                    .putLong("${prefix}_analysis_time", now)
                    .putInt("${prefix}_analysis_accepted", analysis.acceptedNumbers)
                    .putInt("${prefix}_analysis_unique", analysis.uniqueNumbers)
                    .putStringSet("${prefix}_special_numbers", currentSpecialNumbers)

                if (newlySpecialNumbers.isNotEmpty()) {
                    val specialDetails = newlySpecialNumbers.take(6).map { number ->
                        val record = analysis.accepted.firstOrNull { it.number == number }
                        if (record != null) "$number (م${record.group}/ب${record.item})" else number
                    }
                    changes.add("$simLabel — أرقام جديدة مميزة وفق المواصفة (+${newlySpecialNumbers.size}): ${specialDetails.joinToString("، ")}")
                }
                if (removedSpecialNumbers.isNotEmpty()) {
                    changes.add("$simLabel — أرقام مميزة لم تعد ظاهرة (-${removedSpecialNumbers.size}): ${removedSpecialNumbers.take(6).joinToString("، ")}")
                }
                // Recompute on every complete snapshot so the report and special-number set
                // always describe exactly the current saved inventory.
            }

            val modeHistory = JSONObject()
                .put("sim_type", simType)
                .put("sim_label", simLabel)
                .put("price", price)
                .put("count", count)
                .put("loaded", loaded)
                .put("total", total)
                .put("counter_mode", counterMode)
                .put("source", source)
                .put("list_source", listSource)
                .put("number_cards", numberCardsCount)
                .put("numbers", numbers.size)
                .put("numbers_complete", completeNumberList)
                .put("added", addedNumbers.size)
                .put("removed", removedNumbers.size)
                .put("added_numbers", JSONArray().apply { addedNumbers.forEach { put(it) } })
                .put("removed_numbers", JSONArray().apply { removedNumbers.forEach { put(it) } })
            historyModes.put(modeHistory)
            if (primaryResult == null) primaryResult = item
            successfulModes++
        }

        if (successfulModes == 0) {
            saveFailure("لم تُقرأ قيمة صالحة لعداد Number of Lines في SIM أو eSIM")
            return Result.retry()
        }

        val first = primaryResult ?: JSONObject()
        val history = readHistory(preferences)
        history.put(
            JSONObject()
                .put("time", now)
                .put("ok", true)
                .put("modes", historyModes)
                .put("mode_count", successfulModes)
                .put("change", changes.joinToString(" | "))
        )
        trimHistory(history)

        // Retain the legacy summary keys so installations upgraded from earlier versions
        // continue to show a useful last reading while mode-specific values live separately.
        editor.putInt("count", first.optInt("count", -1))
            .putInt("loaded", first.optInt("loaded", -1))
            .putInt("total", first.optInt("total", -1))
            .putString("counter_mode", first.optString("counterMode", first.optString("mode", "single")))
            .putString("source", first.optString("source", "غير محدد"))
            .putLong("time", now)
            .putLong("attempt_time", now)
            .putBoolean("last_ok", true)
            .putString("error", "")
            .putInt("last_modes_checked", successfulModes)
            .putString("last_primary_mode", first.optString("simType", "unknown"))
            .putString("mode_warnings", warningsText)
            .putString("history", history.toString())
            .apply()

        if (changes.isNotEmpty()) notifyChange(changes.joinToString("\n"))
        return Result.success()
    }

    private fun saveFailure(message: String) {
        val preferences = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val history = readHistory(preferences)
        history.put(JSONObject().put("time", now).put("ok", false).put("error", message))
        trimHistory(history)
        preferences.edit()
            .putBoolean("last_ok", false)
            .putString("error", message)
            .putString("mode_warnings", "")
            .putLong("attempt_time", now)
            .putString("history", history.toString())
            .apply()
    }

    private fun readHistory(contextPreferences: android.content.SharedPreferences): JSONArray = try {
        JSONArray(contextPreferences.getString("history", "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun trimHistory(history: JSONArray) {
        while (history.length() > MAX_HISTORY_ITEMS) history.remove(0)
    }

    private suspend fun scrape(): JSONObject? = suspendCancellableCoroutine { continuation ->
        val handler = Handler(Looper.getMainLooper())
        val webView = try {
            WebView(applicationContext)
        } catch (_: Exception) {
            if (continuation.isActive) continuation.resume(null)
            return@suspendCancellableCoroutine
        }

        val targetModes = listOf("physical", "esim")
        val capturedModes = JSONArray()
        val modeWarnings = JSONArray()
        var targetIndex = 0
        var lastPayload = ""
        var stableCount = 0
        var attempts = 0
        var finished = false
        var pageLoadError = ""
        lateinit var poll: Runnable

        fun finish(value: JSONObject?) {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            try {
                webView.stopLoading()
                webView.destroy()
            } catch (_: Exception) {
                // Ignore teardown errors.
            }
            if (continuation.isActive) continuation.resume(value)
        }

        fun nextMode() {
            targetIndex++
            lastPayload = ""
            stableCount = 0
            attempts = 0
            if (targetIndex >= targetModes.size) {
                if (capturedModes.length() > 0) {
                    finish(JSONObject().put("modes", capturedModes).put("warnings", modeWarnings))
                } else {
                    finish(JSONObject().put("error", "لم تُقرأ بيانات SIM Card أو eSIM من الصفحة"))
                }
                return
            }
            val target = targetModes[targetIndex]
            webView.evaluateJavascript(SELECT_MODE_JS.replace("__MODE__", target)) {
                handler.postDelayed(poll, MODE_SWITCH_DELAY_MS)
            }
        }

        poll = object : Runnable {
            override fun run() {
                if (finished) return
                if (pageLoadError.isNotBlank()) {
                    if (capturedModes.length() > 0) {
                        modeWarnings.put(pageLoadError)
                        finish(JSONObject().put("modes", capturedModes).put("warnings", modeWarnings))
                    } else {
                        finish(JSONObject().put("error", pageLoadError))
                    }
                    return
                }
                try {
                    webView.evaluateJavascript(JS) { raw ->
                        if (finished) return@evaluateJavascript
                        val payload = try {
                            val decoded = JSONTokener(raw ?: "null").nextValue()
                            decoded as? String ?: ""
                        } catch (_: Exception) {
                            ""
                        }
                        attempts++
                        stableCount = if (payload.isNotBlank() && payload == lastPayload) stableCount + 1 else 0
                        lastPayload = payload

                        if (payload.isNotBlank()) {
                            val parsed = try { JSONObject(payload) } catch (_: Exception) { null }
                            val error = parsed?.optString("error", "")?.trim().orEmpty()
                            if (error.isNotEmpty()) {
                                modeWarnings.put("${targetModes[targetIndex]}: $error")
                                if (attempts >= MAX_MODE_ATTEMPTS) {
                                    if (targetIndex < targetModes.lastIndex) nextMode()
                                    else if (capturedModes.length() > 0) finish(JSONObject().put("modes", capturedModes).put("warnings", modeWarnings))
                                    else finish(JSONObject().put("error", error))
                                } else {
                                    handler.postDelayed(this, POLL_INTERVAL_MS)
                                }
                                return@evaluateJavascript
                            }

                            val activeMode = parsed?.optString("simType", "") ?: ""
                            val targetMode = targetModes[targetIndex]
                            if (parsed != null && activeMode == targetMode &&
                                parsed.optBoolean("modeConfirmed", false) && stableCount >= STABLE_READS_REQUIRED) {
                                val waitingForInventory = parsed.optString("counterMode") == "pair" &&
                                    parsed.optInt("total", 0) > 0 &&
                                    !parsed.optBoolean("numbersComplete", false)
                                if (attempts < MIN_MODE_ATTEMPTS || (waitingForInventory && attempts < MAX_MODE_ATTEMPTS)) {
                                    handler.postDelayed(this, POLL_INTERVAL_MS)
                                } else {
                                    capturedModes.put(parsed)
                                    nextMode()
                                }
                                return@evaluateJavascript
                            }
                        }

                        if (attempts >= MAX_MODE_ATTEMPTS) {
                            modeWarnings.put("تعذّر الحصول على قراءة مستقرة لنوع ${targetModes[targetIndex]}")
                            if (targetIndex < targetModes.lastIndex) nextMode()
                            else if (capturedModes.length() > 0) finish(JSONObject().put("modes", capturedModes).put("warnings", modeWarnings))
                            else finish(JSONObject().put("error", "لم يتمكن التطبيق من قراءة بيانات SIM Card أو eSIM بشكل مستقر"))
                        } else {
                            handler.postDelayed(this, POLL_INTERVAL_MS)
                        }
                    }
                } catch (_: Exception) {
                    attempts++
                    if (attempts >= MAX_MODE_ATTEMPTS) {
                        modeWarnings.put("حدث خطأ أثناء قراءة النوع ${targetModes[targetIndex]}")
                        if (targetIndex < targetModes.lastIndex) nextMode()
                        else if (capturedModes.length() > 0) finish(JSONObject().put("modes", capturedModes).put("warnings", modeWarnings))
                        else finish(null)
                    } else {
                        handler.postDelayed(this, POLL_INTERVAL_MS)
                    }
                }
            }
        }

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = false
        webView.settings.blockNetworkImage = true
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) webView.settings.safeBrowsingEnabled = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                handler.removeCallbacks(poll)
                webView.evaluateJavascript(SELECT_MODE_JS.replace("__MODE__", "physical")) {
                    handler.postDelayed(poll, INITIAL_POLL_DELAY_MS)
                }
            }

            override fun onReceivedError(
                view: WebView?, request: WebResourceRequest?, error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) pageLoadError = "تعذّر تحميل صفحة فودافون بسبب خطأ اتصال."
            }

            override fun onReceivedHttpError(
                view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
            ) {
                if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                    pageLoadError = "رفض خادم فودافون تحميل الصفحة (HTTP ${errorResponse?.statusCode})."
                }
            }
        }

        continuation.invokeOnCancellation {
            handler.post {
                handler.removeCallbacksAndMessages(null)
                try { webView.stopLoading(); webView.destroy() } catch (_: Exception) {}
            }
        }

        try { webView.loadUrl(PAGE) } catch (_: Exception) { finish(null) }
    }

    private fun notifyChange(message: String) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "مراقبة فودافون RED", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("تغيّر في أرقام فودافون RED")
            .setContentText(message.substringBefore('\n'))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (_: SecurityException) {
            // Notifications are unavailable until the user grants permission.
        }
    }

    companion object {
        const val PREFS = "vf"
        const val PERIODIC_WORK = "vf-watch"
        const val MANUAL_WORK = "vf-manual-check"
        const val CHANNEL_ID = "vf_watch_changes"
        const val NOTIFICATION_ID = 701

        const val PAGE = "https://eshop.vodafone.com.eg/en/lines/red/numbers?channelId=REDPlanAR&c_id=DACS0335&c_medium=PPC&c_name=REDPlanAR&c_source=Search&c_term=REDPlanAR&c_type=Anonymous"

        private const val SCRAPE_TIMEOUT_MS = 110_000L
        private const val INITIAL_POLL_DELAY_MS = 2_000L
        private const val MODE_SWITCH_DELAY_MS = 4_000L
        private const val POLL_INTERVAL_MS = 1_500L
        private const val MAX_MODE_ATTEMPTS = 22
        private const val MIN_MODE_ATTEMPTS = 6
        private const val STABLE_READS_REQUIRED = 2
        private const val MAX_HISTORY_ITEMS = 40

        const val SELECT_MODE_JS = """(function(){
          var radio = document.querySelector('input[name="redLinesSimType"][value="__MODE__"]');
          if(!radio) return 'missing';
          if(!radio.checked) radio.click();
          return radio.checked ? 'selected' : 'pending';
        })()"""

        // Read the live RED panel only after the requested SIM selector has become active.
        // Prices are extracted from the page labels on every scan; they are not hard-coded.
        const val JS = """(function(){
          function asciiDigits(value){
            return String(value == null ? '' : value)
              .replace(/[٠-٩]/g, function(ch){ return String(ch.charCodeAt(0) - 1632); })
              .replace(/[۰-۹]/g, function(ch){ return String(ch.charCodeAt(0) - 1776); })
              .replace(/[٬]/g, ',');
          }
          function cleanText(el){
            if(!el) return '';
            var raw = el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
            return asciiDigits(raw).replace(/\s+/g,' ').trim();
          }
          function parseCounterText(raw){
            var text = asciiDigits(raw).replace(/\s+/g,' ').trim();
            if(!text) return null;
            var label = /(?:number\s+of\s+lines|عدد\s+الخطوط)/i;
            var labelMatch = label.exec(text);
            if(labelMatch){
              var after = text.slice(labelMatch.index + labelMatch[0].length);
              if((after.match(/\d[\d,]*/g) || []).length) text = after;
            }
            var pair = text.match(/(\d[\d,]*)\s*\/\s*(\d[\d,]*)/);
            var values = text.match(/\d[\d,]*/g) || [];
            function asInt(v){ return parseInt(String(v).replace(/,/g,''),10); }
            var mode = 'single', loaded, total, count;
            if(pair){ loaded=asInt(pair[1]); total=asInt(pair[2]); count=total; mode='pair'; }
            else if(values.length){ count=asInt(values[values.length-1]); loaded=count; total=count; }
            else return null;
            if(!Number.isFinite(count) || count < 0 || loaded > total) return null;
            return {count:count, loaded:loaded, total:total, counterMode:mode};
          }
          function queryAll(selector){
            try { return Array.prototype.slice.call(document.querySelectorAll(selector) || []); }
            catch(e) { return []; }
          }
          function sameValue(a,b){
            return a && b && a.counterMode===b.counterMode && a.loaded===b.loaded && a.total===b.total;
          }

          var radios = queryAll('input[name="redLinesSimType"]');
          var checkedRadio = radios.find(function(r){ return !!r.checked; }) || null;
          var simType = checkedRadio ? checkedRadio.value : (radios.length ? radios[0].value : 'unknown');
          var simOptions = radios.map(function(r){
            var label = r.closest ? r.closest('label') : null;
            var labelText = cleanText(label);
            var priceNode = label ? label.querySelector('span[id*=\"lines-type-switcher-span\"]') : null;
            return {type:r.value, label:labelText, price:cleanText(priceNode)};
          });
          var selectedOption = simOptions.find(function(o){ return o.type===simType; }) || {};

          var counterSelectors = [
            '#red-panel vf-lines-pool .lines-count-footer .lines-numbers',
            'vf-lines-pool .lines-count-footer .lines-numbers',
            '.lines-count-footer .lines-numbers',
            '#vf-lines-p', '[data-testid="vf-lines-p"]', '[data-cy="vf-lines-p"]',
            '.vf-lines-p', 'vf-lines-p', '[id*="vf-lines-p"]', '.lines-numbers'
          ];
          var parsed = null, counterSource = '';
          for(var i=0;i<counterSelectors.length && !parsed;i++){
            var nodes=queryAll(counterSelectors[i]);
            if(!nodes.length) continue;
            var readings=[];
            nodes.forEach(function(node){
              var value=parseCounterText(cleanText(node));
              if(!value){
                var attr=node.getAttribute('data-value') || node.value || node.getAttribute('aria-label') || '';
                value=parseCounterText(attr);
              }
              if(value) readings.push(value);
            });
            if(readings.length){
              parsed=readings[0]; counterSource=counterSelectors[i];
              for(var r=1;r<readings.length;r++){
                if(!sameValue(parsed,readings[r])) return JSON.stringify({error:'ظهرت قراءات متعارضة لعداد Number of Lines'});
              }
            }
          }
          if(!parsed){
            var labelPattern=/^(?:number\s+of\s+lines|عدد\s+الخطوط)(?:\s*[:：-]?\s*[\d,]+(?:\s*\/\s*[\d,]+)?)?$/i;
            var leaves=queryAll('body *');
            for(var j=0;j<leaves.length && !parsed;j++){
              var el=leaves[j]; if(el.children && el.children.length) continue;
              if(!labelPattern.test(cleanText(el))) continue;
              parsed=parseCounterText(cleanText(el));
              if(parsed){counterSource='label-text';break;}
              var adjacent=[el.nextElementSibling,el.parentElement,el.parentElement && el.parentElement.nextElementSibling];
              for(var k=0;k<adjacent.length && !parsed;k++){
                if(adjacent[k]){parsed=parseCounterText(cleanText(adjacent[k]));if(parsed)counterSource='label-adjacent';}
              }
            }
          }
          if(!parsed){
            var bodyText=cleanText(document.body).toLowerCase();
            if(/captcha|access denied|cloudflare|حدث خطأ|يرجى المحاولة|يرجى المحاوله/.test(bodyText))
              return JSON.stringify({error:'ظهرت رسالة خطأ أو خطوة تحقق بدل بيانات العداد'});
            return '';
          }

          function extractParagraphNumbers(paragraph){
            if(!paragraph) return [];
            // Inventory extraction uses paragraph text only; the analyzer later filters 010xxxxxxxx per the specification.
            var text=asciiDigits(paragraph.innerText || paragraph.textContent || '');
            // Treat presentation punctuation as separators inside one digit run, then validate
            // the complete run so an extra digit before/after a hyphen cannot be ignored.
            var matcher=/[0-9]+(?:[\s().,+،-]*[0-9]+)*/g;
            var values=[], match;
            while((match=matcher.exec(text))!==null){
              var number=match[0].replace(/\D/g,'');
              if(/^01[0125]\d{8}$/.test(number)) values.push(number);
            }
            return values;
          }
          var cardSelector='#red-panel vf-lines-pool .msisdn-item-container[role="button"]';
          var cards=queryAll(cardSelector);
          if(!cards.length){cardSelector='vf-lines-pool .msisdn-item-container[role="button"]';cards=queryAll(cardSelector);}
          var rawNumbers=[];
          if(cards.length){
            cards.forEach(function(card){
              var paragraphs=[];
              try{
                var nodes=card.querySelectorAll('.msisdn-item p');
                if(nodes) paragraphs=Array.prototype.slice.call(nodes);
              }catch(e){}
              if(!paragraphs.length){
                try{
                  var paragraph=card.querySelector('.msisdn-item p');
                  if(paragraph) paragraphs=[paragraph];
                }catch(e){}
              }
              paragraphs.forEach(function(paragraph){
                rawNumbers=rawNumbers.concat(extractParagraphNumbers(paragraph));
              });
            });
          }else{
            var numberElements=queryAll('vf-lines-pool .msisdn-item p');
            if(!numberElements.length) numberElements=queryAll('.msisdn-item p');
            cards=numberElements;
            numberElements.forEach(function(el){rawNumbers=rawNumbers.concat(extractParagraphNumbers(el));});
          }
          var uniqueNumbers=Array.from(new Set(rawNumbers));
          var cardCount=cards.length;
          var numbersComplete=parsed.counterMode==='pair' && parsed.loaded===parsed.total && parsed.total>0 &&
            cardCount===parsed.loaded && rawNumbers.length===parsed.loaded && uniqueNumbers.length===parsed.loaded;
          return JSON.stringify({
            simType:simType,
            simLabel:selectedOption.label || simType,
            price:selectedOption.price || '',
            availableModes:radios.map(function(r){return r.value;}),
            modeConfirmed:!!checkedRadio,
            count:parsed.count, loaded:parsed.loaded, total:parsed.total,
            counterMode:parsed.counterMode, source:counterSource || 'label-fallback',
            listSource:cardSelector + ' .msisdn-item p',
            numberCardsCount:cardCount, rawNumbersCount:rawNumbers.length, numbersCount:uniqueNumbers.length,
            numbersComplete:numbersComplete, rawNumbers:rawNumbers, numbers:uniqueNumbers
          });
        })()"""
    }
}
