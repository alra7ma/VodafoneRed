#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 8 -Xlint:-options -d "$TMP" \
  "$ROOT/app/src/main/java/com/example/vfwatch/SpecialNumberAnalyzer.java" \
  "$ROOT/tools/tests/SpecialNumberAnalyzerTest.java"
java -cp "$TMP" com.example.vfwatch.SpecialNumberAnalyzerTest
