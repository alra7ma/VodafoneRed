'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const evidence = require('./fixtures/vodafone-red-dom-evidence.json');

const workerPath = path.join(__dirname, '..', 'app', 'src', 'main', 'java', 'com', 'example', 'vfwatch', 'CheckWorker.kt');
const worker = fs.readFileSync(workerPath, 'utf8');
const match = worker.match(/const val JS = """([\s\S]*?)"""/);
assert.ok(match, 'Could not find embedded extractor JavaScript in CheckWorker.kt');
const extractor = match[1];
const selectMatch = worker.match(/const val SELECT_MODE_JS = "{3}([\s\S]*?)"{3}/);
assert.ok(selectMatch, 'Could not find SIM-mode selection script in CheckWorker.kt');
const selectModeScript = selectMatch[1];

function selectMode(mode, radios) {
  const document = {
    querySelector(selector) {
      const found = selector.match(/value="(physical|esim)"/);
      return found ? radios.find(r => r.value === found[1]) || null : null;
    }
  };
  return vm.runInNewContext(selectModeScript.replace('__MODE__', mode), { document });
}

function element(text, overrides = {}) {
  return Object.assign({
    innerText: text,
    textContent: text,
    children: [],
    value: '',
    getAttribute: () => '',
    nextElementSibling: null,
    parentElement: null,
    querySelector: () => null
  }, overrides);
}

function numberCard(number, includeParagraph = true) {
  const numberNode = includeParagraph ? element(number) : null;
  return element('', {
    querySelector(selector) {
      return selector === '.msisdn-item p' ? numberNode : null;
    },
    querySelectorAll(selector) {
      return selector === '.msisdn-item p' && numberNode ? [numberNode] : [];
    },
    getAttribute(name) {
      // Deliberately contains a number to verify that aria-label is never used as an input source.
      return name === 'aria-label' ? `Select number ${number}` : '';
    }
  });
}

function radio(value, checked, labelText, priceText) {
  const price = element(priceText);
  const label = element(labelText, { querySelector: selector => selector.includes('lines-type-switcher-span') ? price : null });
  return {
    value,
    checked,
    closest: selector => selector === 'label' ? label : null
  };
}

function execute({ selectorLists = {}, selectors = {}, leaves = [], cards = [], numbers = [], bodyText = '', radios = null } = {}) {
  const simRadios = radios || [
    radio('physical', true, 'Sim Card 200 EGP', '200 EGP'),
    radio('esim', false, 'eSim 445 EGP', '445 EGP')
  ];
  const document = {
    body: element(bodyText),
    querySelectorAll(selector) {
      if (selector === 'input[name="redLinesSimType"]') return simRadios;
      if (Object.hasOwn(selectorLists, selector)) return selectorLists[selector];
      if (Object.hasOwn(selectors, selector)) {
        const value = selectors[selector];
        return Array.isArray(value) ? value : value ? [value] : [];
      }
      if (selector === 'body *') return leaves;
      if (selector === '#red-panel vf-lines-pool .msisdn-item-container[role="button"]') return cards;
      if (selector === 'vf-lines-pool .msisdn-item-container[role="button"]') return cards;
      if (selector === 'vf-lines-pool .msisdn-item p' || selector === '.msisdn-item p') return numbers;
      return [];
    }
  };
  const raw = vm.runInNewContext(extractor, { document, Number, String, Array, parseInt, JSON });
  return raw ? JSON.parse(raw) : null;
}

const tests = [
  ['matches the supplied HTML evidence and captures physical SIM price', () => {
    assert.equal(evidence.counterSelector, 'vf-lines-pool .lines-count-footer .lines-numbers');
    assert.equal(evidence.counterText, '954 / 954');
    assert.equal(evidence.numberCardElements, 954);
    assert.equal(evidence.simTypeSwitcher.options[0].displayedPrice, '200 EGP');
    assert.equal(evidence.simTypeSwitcher.options[1].displayedPrice, '445 EGP');
    assert.equal(evidence.simTypeSwitcher.priceSelector, 'span[id*="lines-type-switcher-span"]');
    const result = execute({
      selectors: { [evidence.counterSelector]: element(evidence.counterText) },
      cards: Array.from({ length: 954 }, (_, i) => numberCard(`010${String(i).padStart(8, '0')}`))
    });
    assert.equal(result.count, 954);
    assert.equal(result.loaded, 954);
    assert.equal(result.total, 954);
    assert.equal(result.counterMode, 'pair');
    assert.equal(result.simType, 'physical');
    assert.equal(result.price, '200 EGP');
    assert.equal(result.modeConfirmed, true);
    assert.deepEqual(Array.from(result.availableModes), ['physical', 'esim']);
    assert.equal(result.numberCardsCount, 954);
    assert.equal(result.numbersCount, 954);
    assert.equal(result.numbersComplete, true);
  }],
  ['identifies eSIM mode and reads the eSIM price independently', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('320 / 320') },
      cards: Array.from({ length: 320 }, (_, i) => numberCard(`010${String(i + 2000).padStart(8, '0')}`)),
      radios: [radio('physical', false, 'Sim Card 200 EGP', '200 EGP'), radio('esim', true, 'eSim 445 EGP', '445 EGP')]
    });
    assert.equal(result.simType, 'esim');
    assert.equal(result.price, '445 EGP');
    assert.equal(result.count, 320);
    assert.equal(result.numbersComplete, true);
  }],
  ['accepts duplicate responsive counter nodes when their values agree', () => {
    const result = execute({
      selectorLists: { [evidence.counterSelector]: [element('954 / 954'), element('954 / 954')] },
      cards: Array.from({ length: 954 }, (_, i) => numberCard(`010${String(i).padStart(8, '0')}`))
    });
    assert.equal(result.count, 954);
    assert.equal(result.numbersComplete, true);
  }],
  ['rejects conflicting duplicate counter readings', () => {
    const result = execute({ selectorLists: { [evidence.counterSelector]: [element('954 / 954'), element('953 / 954')] } });
    assert.match(result.error, /قراءات متعارضة/);
  }],
  ['supports a legacy single counter fallback', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,779') } });
    assert.equal(result.count, 1779);
    assert.equal(result.counterMode, 'single');
    assert.equal(result.source, '#vf-lines-p');
  }],
  ['parses loaded / total pair', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('1,700 / 1,779') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
    assert.equal(result.counterMode, 'pair');
  }],
  ['normalizes Arabic-Indic digits and Arabic thousands separator', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('١٬٧٠٠ / ١٬٧٧٩') } });
    assert.equal(result.loaded, 1700);
    assert.equal(result.total, 1779);
  }],
  ['fallback reads value adjacent to Arabic label', () => {
    const label = element('عدد الخطوط');
    label.nextElementSibling = element('١٬٧٧٩');
    const result = execute({ leaves: [label] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-adjacent');
  }],
  ['fallback parses English label with inline value', () => {
    const result = execute({ leaves: [element('Number of Lines: 1,779')] });
    assert.equal(result.count, 1779);
    assert.equal(result.source, 'label-text');
  }],
  ['never infers the counter from phone numbers alone', () => {
    const result = execute({ numbers: [element('01012345678')] });
    assert.equal(result, null);
  }],
  ['detects error or verification screens', () => {
    const result = execute({ bodyText: 'حدث خطأ يرجى المحاولة مرة أخرى' });
    assert.match(result.error, /خطوة تحقق/);
  }],
  ['deduplicates valid values but marks duplicate cards incomplete', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 2') },
      cards: [numberCard('01012345678'), numberCard('01012345678')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678']);
    assert.equal(result.numberCardsCount, 2);
    assert.equal(result.rawNumbersCount, 2);
    assert.deepEqual(Array.from(result.rawNumbers), ['01012345678', '01012345678']);
    assert.equal(result.numbersComplete, false);
  }],
  ['extracts raw occurrences from paragraph text and normalizes formatted Arabic digits', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 2') },
      cards: [numberCard('الرقم ٠١٠-١٢٣٤٥٦٧٨'), numberCard('010.12345679')]
    });
    assert.deepEqual(Array.from(result.rawNumbers), ['01012345678', '01012345679']);
    assert.deepEqual(Array.from(result.numbers), ['01012345678', '01012345679']);
    assert.equal(result.rawNumbersCount, 2);
    assert.equal(result.numbersComplete, true);
  }],
  ['preserves all valid Egyptian mobile prefixes in the monitored inventory', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('4 / 4') },
      cards: ['01012345678', '01112345678', '01212345678', '01512345678'].map(number => numberCard(number))
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678', '01112345678', '01212345678', '01512345678']);
    assert.equal(result.numbersComplete, true);
  }],
  ['reads every matching paragraph inside each number card', () => {
    const multiParagraphCard = element('', {
      querySelectorAll(selector) {
        return selector === '.msisdn-item p' ? [element('01012345678'), element('01112345678')] : [];
      },
      querySelector: () => null
    });
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 2') },
      cards: [multiParagraphCard, numberCard('01212345678')]
    });
    assert.deepEqual(Array.from(result.rawNumbers), ['01012345678', '01112345678', '01212345678']);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not use aria-label when the paragraph is absent', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('1 / 1') },
      cards: [numberCard('01012345678', false)]
    });
    assert.deepEqual(Array.from(result.rawNumbers), []);
    assert.deepEqual(Array.from(result.numbers), []);
    assert.equal(result.numbersComplete, false);
  }],
  ['rejects an 010 sequence embedded inside a longer digit run', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('1 / 1') },
      cards: [numberCard('010123456780')]
    });
    assert.deepEqual(Array.from(result.rawNumbers), []);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not accept extra digits separated by formatting punctuation', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 2') },
      cards: [numberCard('01012345678-9'), numberCard('9-01012345678')]
    });
    assert.deepEqual(Array.from(result.rawNumbers), []);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not mark a partial card list as complete', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('954 / 954') },
      cards: Array.from({ length: 953 }, (_, i) => numberCard(`010${String(i).padStart(8, '0')}`))
    });
    assert.equal(result.numberCardsCount, 953);
    assert.equal(result.numbersCount, 953);
    assert.equal(result.numbersComplete, false);
  }],
  ['rejects malformed and invalid Egyptian mobile prefixes', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('3 / 3') },
      cards: [numberCard('01012345678'), numberCard('01312345678'), numberCard('0101234567')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678']);
    assert.equal(result.numbersComplete, false);
  }],
  ['does not mark a partial loaded count as a full inventory', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 3') },
      cards: [numberCard('01012345678'), numberCard('01012345679')]
    });
    assert.equal(result.numbersComplete, false);
  }],
  ['supports paragraph fallback when card wrappers change', () => {
    const result = execute({
      selectors: { [evidence.counterSelector]: element('2 / 2') },
      numbers: [element('01012345678'), element('01012345679')]
    });
    assert.deepEqual(Array.from(result.numbers), ['01012345678', '01012345679']);
    assert.equal(result.numberCardsCount, 2);
    assert.equal(result.numbersComplete, true);
  }],
  ['rejects a loaded count greater than the total', () => {
    const result = execute({ selectors: { '#vf-lines-p': element('4 / 3') } });
    assert.equal(result, null);
  }],
  ['keeps SIM and eSIM prices separate when both options are present', () => {
    const radios = [radio('physical', false, 'Sim Card 200 EGP', '200 EGP'), radio('esim', true, 'eSim 445 EGP', '445 EGP')];
    const result = execute({ selectors: { [evidence.counterSelector]: element('1 / 1') }, cards: [numberCard('01012345678')], radios });
    assert.equal(result.simType, 'esim');
    assert.equal(result.price, '445 EGP');
    assert.deepEqual(Array.from(result.availableModes), ['physical', 'esim']);
  }],
  ['switches the page to the requested physical SIM radio option', () => {
    const radios = [{ value: 'physical', checked: false, click() { radios.forEach(r => r.checked = false); this.checked = true; } },
      { value: 'esim', checked: true, click() { radios.forEach(r => r.checked = false); this.checked = true; } }];
    assert.equal(selectMode('physical', radios), 'selected');
    assert.equal(radios[0].checked, true);
    assert.equal(radios[1].checked, false);
  }],
  ['switches the page to the requested eSIM radio option', () => {
    const radios = [{ value: 'physical', checked: true, click() { radios.forEach(r => r.checked = false); this.checked = true; } },
      { value: 'esim', checked: false, click() { radios.forEach(r => r.checked = false); this.checked = true; } }];
    assert.equal(selectMode('esim', radios), 'selected');
    assert.equal(radios[0].checked, false);
    assert.equal(radios[1].checked, true);
  }],
  ['reports a missing SIM option instead of silently selecting another', () => {
    assert.equal(selectMode('esim', [{ value: 'physical', checked: true, click() {} }]), 'missing');
  }],
  ['uses independent persisted inventory keys and independent app tabs', () => {
    const workerHasModePrefix = worker.includes('val prefix = "mode_$simType"');
    const uiHasModePrefix = fs.readFileSync(path.join(__dirname, '..', 'app', 'src', 'main', 'java', 'com', 'example', 'vfwatch', 'MainActivity.kt'), 'utf8').includes('private fun modePrefix(mode: String = selectedSimMode) = "mode_$mode"');
    assert.equal(workerHasModePrefix, true);
    assert.equal(uiHasModePrefix, true);
  }]
];

for (const [name, test] of tests) {
  test();
  process.stdout.write(`PASS ${name}\n`);
}
process.stdout.write(`\n${tests.length} extractor tests passed.\n`);
