package com.example.vfwatch;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class SpecialNumberAnalyzerTest {
    private static int passed = 0;

    public static void main(String[] args) {
        test("reference repository has exactly 98 units", () -> eq(98, SpecialNumberAnalyzer.referenceUnitCount()));
        test("preserves 010 numbers as strings and rejects invalid lengths", () -> {
            truth(SpecialNumberAnalyzer.isTargetNumber("01000012345"));
            truth(!SpecialNumberAnalyzer.isTargetNumber("10100012345"));
            truth(!SpecialNumberAnalyzer.isTargetNumber("0100001234"));
            truth(!SpecialNumberAnalyzer.isTargetNumber("0100001234X"));
        });
        test("pattern 1: 010000ABCDE", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01000012345"), 1));
        test("pattern 2: 010ABCDABCD", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01012341234"), 2));
        test("pattern 3: 010ABABCDCD", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01012123434"), 3));
        test("pattern 4: 010AABBCCDD", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01011223344"), 4));
        test("pattern 5: 010ABCDDCBA", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01012344321"), 5));
        test("pattern 6: 010ABCBA010", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01012321010"), 6));
        test("pattern 7 accepts ascending suffixes of four digits", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01099111234"), 7));
        test("pattern 7 accepts ascending suffixes of five digits", () -> contains(SpecialNumberAnalyzer.matchingPatterns("01099012345"), 7));
        test("pattern 7 does not accept an incomplete ascending suffix", () -> truth(!contains(SpecialNumberAnalyzer.matchingPatterns("01099111235"), 7)));
        test("reference path can partition into three exact repository units", () -> {
            List<List<String>> parts = SpecialNumberAnalyzer.referencePartitions("01011113333", 3);
            truth(containsPartition(parts, Arrays.asList("010", "1111", "3333")));
        });
        test("all reference partitions contain three to five units and concatenate exactly", () -> {
            for (int k = 3; k <= 5; k++) {
                for (List<String> partition : SpecialNumberAnalyzer.referencePartitions("01012233344", k)) {
                    eq(k, partition.size());
                    StringBuilder joined = new StringBuilder();
                    for (String unit : partition) joined.append(unit);
                    eq("01012233344", joined.toString());
                }
            }
        });
        test("classification prioritizes Group 1 item 3 over a five-unit partition", () -> {
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                    Collections.singletonList("01011223344"), Collections.singletonList("01011223344"), "SIM Card");
            truth(result.acceptedNumbers == 1);
            eq(1, result.accepted.get(0).group);
            eq(3, result.accepted.get(0).item);
        });
        test("filters non-010 inventory numbers out of both specification statistics", () -> {
            List<String> inventory = Arrays.asList("01000012345", "01112345678", "01212345678", "01512345678");
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                    inventory, inventory, "SIM Card");
            eq(1, result.uniqueNumbers);
            eq(1, result.rawOccurrences);
            eq(1, result.acceptedNumbers);
        });
        test("classifies every published group and item in priority order", () -> {
            assertCategory("01011113333", 1, 1);
            assertCategory("01011223333", 1, 2);
            assertCategory("01011223344", 1, 3);
            assertCategory("01000012223", 1, 4);
            assertCategory("01011122234", 1, 5);
            assertCategory("01012234444", 1, 6);
            assertCategory("01011112234", 2, 1);
            assertCategory("01050710020", 2, 2);
            assertCategory("01014704470", 2, 3);
            assertCategory("01099111234", 2, 4);
            assertCategory("01000098765", 2, 5);
            assertCategory("01012123434", 3, 1);
            assertCategory("01013571357", 3, 2);
            assertCategory("01012321010", 3, 3);
            assertCategory("01012344321", 3, 4);
        });
        test("does not hide a raw-occurrence inconsistency", () -> {
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                    Arrays.asList("01000012345", "01000098765"),
                    Collections.singletonList("01000012345"), "SIM Card");
            eq(1, result.rawOccurrences);
            eq(2, result.uniqueNumbers);
            truth(result.report.contains("تنبيه اتساق"));
        });
        test("analyzes duplicates separately from unique numbers", () -> {
            List<String> unique = Arrays.asList("01000000000", "01000000001", "01000000002", "01000000010", "01000000020");
            List<String> raw = Arrays.asList("01000000000", "01000000000", "01000000001", "01000000002", "01000000010", "01000000020");
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(unique, raw, "SIM Card");
            eq(6, result.rawOccurrences);
            eq(5, result.uniqueNumbers);
            eq(5, result.acceptedNumbers);
            eq(0, result.excludedNumbers);
            truth(result.rawOccurrenceCountKnown);
        });
        test("group 4 records maximal +1 chains, all +1 pairs, and maximal +10 chains", () -> {
            List<String> values = Arrays.asList("01000000000", "01000000001", "01000000002", "01000000010", "01000000020");
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(values, values, "SIM Card");
            eq(1, result.plusOneChains.size());
            eq(3, result.plusOneChains.get(0).members.size());
            eq(2, result.plusOnePairs.size());
            eq(1, result.plusTenChains.size());
            eq(3, result.plusTenChains.get(0).members.size());
            truth(result.report.contains("01000000000 → 01000000001 → 01000000002"));
        });
        test("report states missing raw-occurrence history honestly", () -> {
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                    Collections.singletonList("01000012345"), null, "eSIM");
            truth(!result.rawOccurrenceCountKnown);
            truth(result.report.contains("عدد الظهورات الخام التاريخي غير محفوظ"));
        });
        test("acceptance paths and group records are populated", () -> {
            SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                    Collections.singletonList("01000012345"), Collections.singletonList("01000012345"), "eSIM");
            eq(1, result.acceptedNumbers);
            eq(result.acceptedNumbers, result.referenceOnly + result.patternOnly + result.dualAccepted);
            truth(result.report.contains("النتيجة النهائية"));
        });
        System.out.println("\n" + passed + " special-number analyzer tests passed.");
    }

    private static void assertCategory(String number, int expectedGroup, int expectedItem) {
        SpecialNumberAnalyzer.Analysis result = SpecialNumberAnalyzer.analyze(
                Collections.singletonList(number), Collections.singletonList(number), "test");
        if (result.accepted.isEmpty()) throw new AssertionError("expected acceptance for " + number);
        eq(expectedGroup, result.accepted.get(0).group);
        eq(expectedItem, result.accepted.get(0).item);
    }

    private static boolean contains(List<Integer> values, int expected) { return values.contains(expected); }

    private static boolean containsPartition(List<List<String>> values, List<String> expected) {
        for (List<String> value : values) if (value.equals(expected)) return true;
        return false;
    }

    private static void test(String name, Runnable block) {
        try {
            block.run();
            passed++;
            System.out.println("PASS " + name);
        } catch (Throwable error) {
            System.err.println("FAIL " + name + ": " + error.getMessage());
            error.printStackTrace();
            System.exit(1);
        }
    }

    private static void eq(int expected, int actual) {
        if (expected != actual) throw new AssertionError("expected " + expected + " but was " + actual);
    }

    private static void eq(String expected, String actual) {
        if (!expected.equals(actual)) throw new AssertionError("expected " + expected + " but was " + actual);
    }

    private static void truth(boolean condition) {
        if (!condition) throw new AssertionError("condition was false");
    }
}
